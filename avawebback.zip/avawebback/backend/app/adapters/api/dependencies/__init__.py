from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID

from app.infrastructure.database import get_session
from app.infrastructure.config import settings


async def get_db():
    async for session in get_session():
        yield session
