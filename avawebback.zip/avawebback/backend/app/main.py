from fastapi import FastAPI


def create_app() -> FastAPI:
    application = FastAPI(
        title="Avaliação Backend",
        description="Sistema Backend da Avaliação — Clean Architecture + TDD",
        version="0.1.0",
    )

    @application.get("/")
    async def health_check():
        return {"status": "ok"}

    return application


app = create_app()
